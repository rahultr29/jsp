import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/Register")
public class Register extends HttpServlet
{
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		PrintWriter pw=res.getWriter();		//to print on the browser the response
		res.setContentType("text/html");
		String username=req.getParameter("username");
		String password=req.getParameter("password");
		String email=req.getParameter("email");
		String gender=req.getParameter("gender");
		String dob=req.getParameter("dob");
		
		
				try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
			
			PreparedStatement st=con.prepareStatement("insert into user_register values(?,?,?,?,?)");
			st.setString(1, username);
			st.setString(2, email);
			st.setString(3, password);
			st.setString(4,gender);
			st.setString(5,dob);
			st.execute();
			System.out.println("User Register");
			
			res.sendRedirect("Login.html");
			
		
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
			}

}