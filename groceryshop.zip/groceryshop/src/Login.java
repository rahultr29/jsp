
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/Login")
public class Login extends HttpServlet
{
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		PrintWriter pw=res.getWriter();		//to print on the browser the response
		res.setContentType("text/html");
		String email1=req.getParameter("email");
		String password1=req.getParameter("password");
						try
		{
							
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		PreparedStatement ps=con.prepareStatement("select * from user_register where email=? and password=?");
		ps.setString(1,email1);
		ps.setString(2,password1);
			ResultSet rs=ps.executeQuery();
			if(email1.equalsIgnoreCase("rahultelkar") && password1.equalsIgnoreCase("12345")){
				res.sendRedirect("admin.html");
			}
			else{
				
			
			while(rs.next())
			{
				res.sendRedirect("home.html");
			}
			res.sendRedirect("Login.html");
			}}
				catch(Exception ae)
				{
				}
	}
				}