import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/addfeedback")
public class addfeedback extends HttpServlet
{
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		PrintWriter pw=res.getWriter();		//to print on the browser the response
		res.setContentType("text/html");
		String name=req.getParameter("name");
		String feedback=req.getParameter("feedback");
		
		
		
				try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
			
			PreparedStatement st=con.prepareStatement("insert into user_feedbackr values(?,?)");
			st.setString(1, name);
			st.setString(2, feedback);
			
			st.execute();
			System.out.println("Feedback added");
			
			res.sendRedirect("addfeedback.html");
			
		
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
			}

}